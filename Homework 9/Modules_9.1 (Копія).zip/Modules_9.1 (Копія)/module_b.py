from module_a import welcomer

name = input("Enter your name: ")
print(welcomer(name))

