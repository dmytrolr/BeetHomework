def welcomer (name):
    # Функція яка буде виконуватись після імпорту
    return (f'Hello, {name}!')
